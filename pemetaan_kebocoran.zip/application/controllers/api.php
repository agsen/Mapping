<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('node');
	}

	public function ambil_data_node(){
		$data_node=$this->node->ambil_data()->result();
		$this->output
      			->set_status_header(200)
      			->set_content_type('application/json', 'utf-8')
      			->set_output(json_encode($data_node, JSON_PRETTY_PRINT))
      			->_display();
      			exit;

	}
	public function simpan_data(){
		$data = (array)json_decode(file_get_contents('php://input')); 
		/*$data=array(	'nama_node'=>$body['nama_node'],
					 	'posisi_x'=>$body['posisi_x'],
					 	'posisi_y'=>$body['posisi_y'],
					 	'konsentrasi_gas'=>$body['konsentrasi_gas']);*/
      $this->db->insert('data_node', $data);
      $response = array(
        'Success' => true,
        'Info' => 'Data Tersimpan');

      $this->output
        ->set_status_header(201)
        ->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($response, JSON_PRETTY_PRINT))
        ->_display();
        exit;

	}

	public function simpan_data_node($nama_node,$x,$y,$z){
		$this->node->simpan_data($nama_node,$x,$y,$z);

      $response = array(
        'Success' => true,
        'Info' => 'Data Tersimpan');

      $this->output
        ->set_status_header(201)
        ->set_content_type('application/json', 'utf-8')
        ->set_output(json_encode($response, JSON_PRETTY_PRINT))
        ->_display();
        exit;
  }

}
